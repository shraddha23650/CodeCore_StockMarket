import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Plus, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Warehouses() {
  const { toast } = useToast();
  const [addLocationOpen, setAddLocationOpen] = useState(false);
  const [locationForm, setLocationForm] = useState({
    locationId: "",
    name: "",
    type: "",
    capacity: "",
  });

  const handleAddLocation = () => {
    if (!locationForm.locationId || !locationForm.name || !locationForm.type || !locationForm.capacity) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Location Added",
      description: `Location ${locationForm.name} has been added successfully`,
    });

    setLocationForm({
      locationId: "",
      name: "",
      type: "",
      capacity: "",
    });
    setAddLocationOpen(false);
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Warehouse</h1>
          <p className="text-muted-foreground mt-2">View and manage all warehouse locations</p>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Locations</CardTitle>
                <CardDescription>Manage storage areas and bins</CardDescription>
              </div>
              <Button onClick={() => setAddLocationOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add Location
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search locations..." className="pl-9" />
            </div>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Location ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Capacity</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground py-8">
                    No locations found. Add your first location to get started.
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Add Location Dialog */}
        <Dialog open={addLocationOpen} onOpenChange={setAddLocationOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Location</DialogTitle>
              <DialogDescription>Enter the details for the new warehouse location</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="location-id">Location ID *</Label>
                <Input
                  id="location-id"
                  value={locationForm.locationId}
                  onChange={(e) => setLocationForm({ ...locationForm, locationId: e.target.value })}
                  placeholder="Enter location ID"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="location-name">Name *</Label>
                <Input
                  id="location-name"
                  value={locationForm.name}
                  onChange={(e) => setLocationForm({ ...locationForm, name: e.target.value })}
                  placeholder="Enter location name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="location-type">Type *</Label>
                <Select value={locationForm.type} onValueChange={(value) => setLocationForm({ ...locationForm, type: value })}>
                  <SelectTrigger id="location-type">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="warehouse">Warehouse</SelectItem>
                    <SelectItem value="storage">Storage Area</SelectItem>
                    <SelectItem value="bin">Bin</SelectItem>
                    <SelectItem value="shelf">Shelf</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="location-capacity">Capacity *</Label>
                <Input
                  id="location-capacity"
                  type="number"
                  value={locationForm.capacity}
                  onChange={(e) => setLocationForm({ ...locationForm, capacity: e.target.value })}
                  placeholder="Enter capacity"
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setAddLocationOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddLocation}>
                  Add Location
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}
