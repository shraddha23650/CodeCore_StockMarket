import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function Adjustments() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    item: "",
    location: "",
    currentQty: "0",
    newQty: "",
    reason: "",
  });

  const handleItemChange = (value: string) => {
    // Simulate fetching current quantity when item is selected
    setFormData({ ...formData, item: value, currentQty: "100" });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.item || !formData.location || !formData.newQty || !formData.reason) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Adjustment Created",
      description: `Stock adjusted from ${formData.currentQty} to ${formData.newQty} units`,
    });

    // Reset form
    setFormData({
      item: "",
      location: "",
      currentQty: "0",
      newQty: "",
      reason: "",
    });
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Stock Adjustment</h1>
          <p className="text-muted-foreground mt-2">Adjust stock levels and correct inventory errors</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>New Adjustment</CardTitle>
            <CardDescription>Update inventory quantities manually</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="item">Item</Label>
                <Select value={formData.item} onValueChange={handleItemChange}>
                  <SelectTrigger id="item">
                    <SelectValue placeholder="Select item" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="item1">Item 1</SelectItem>
                    <SelectItem value="item2">Item 2</SelectItem>
                    <SelectItem value="item3">Item 3</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Select value={formData.location} onValueChange={(value) => setFormData({ ...formData, location: value })}>
                  <SelectTrigger id="location">
                    <SelectValue placeholder="Select location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="warehouse-a">Warehouse A</SelectItem>
                    <SelectItem value="warehouse-b">Warehouse B</SelectItem>
                    <SelectItem value="warehouse-c">Warehouse C</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="current-qty">Current Qty</Label>
                <Input 
                  id="current-qty" 
                  type="number" 
                  value={formData.currentQty} 
                  readOnly 
                  className="bg-muted" 
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="new-qty">New Qty</Label>
                <Input 
                  id="new-qty" 
                  type="number" 
                  placeholder="Enter new quantity"
                  value={formData.newQty}
                  onChange={(e) => setFormData({ ...formData, newQty: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="reason">Reason</Label>
                <Textarea 
                  id="reason" 
                  placeholder="Enter reason for adjustment"
                  value={formData.reason}
                  onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                />
              </div>

              <Button type="submit" className="w-full">Create Adjustment</Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
