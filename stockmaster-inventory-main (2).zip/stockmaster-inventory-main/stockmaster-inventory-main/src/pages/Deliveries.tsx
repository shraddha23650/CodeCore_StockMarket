import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Plus, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Deliveries() {
  const { toast } = useToast();
  const [newDeliveryOpen, setNewDeliveryOpen] = useState(false);
  const [deliveryForm, setDeliveryForm] = useState({
    customer: "",
    items: "",
    shipDate: "",
    carrier: "",
  });

  const handleNewDelivery = () => {
    if (!deliveryForm.customer || !deliveryForm.items || !deliveryForm.shipDate || !deliveryForm.carrier) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Delivery Created",
      description: `New delivery order created for ${deliveryForm.customer}`,
    });

    setDeliveryForm({
      customer: "",
      items: "",
      shipDate: "",
      carrier: "",
    });
    setNewDeliveryOpen(false);
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Deliveries</h1>
          <p className="text-muted-foreground mt-2">Manage outgoing shipments and deliveries</p>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Delivery Orders</CardTitle>
                <CardDescription>Track outbound shipments to customers</CardDescription>
              </div>
              <Button onClick={() => setNewDeliveryOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                New Delivery
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search by order number or customer..." className="pl-9" />
            </div>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Order ID</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Items</TableHead>
                  <TableHead>Ship Date</TableHead>
                  <TableHead>Carrier</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                    No deliveries scheduled. Create a delivery order to begin.
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* New Delivery Dialog */}
        <Dialog open={newDeliveryOpen} onOpenChange={setNewDeliveryOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Delivery</DialogTitle>
              <DialogDescription>Enter the details for the new delivery order</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="customer">Customer *</Label>
                <Input
                  id="customer"
                  value={deliveryForm.customer}
                  onChange={(e) => setDeliveryForm({ ...deliveryForm, customer: e.target.value })}
                  placeholder="Enter customer name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="items">Items *</Label>
                <Input
                  id="items"
                  value={deliveryForm.items}
                  onChange={(e) => setDeliveryForm({ ...deliveryForm, items: e.target.value })}
                  placeholder="Enter items"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ship-date">Ship Date *</Label>
                <Input
                  id="ship-date"
                  type="date"
                  value={deliveryForm.shipDate}
                  onChange={(e) => setDeliveryForm({ ...deliveryForm, shipDate: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="carrier">Carrier *</Label>
                <Select value={deliveryForm.carrier} onValueChange={(value) => setDeliveryForm({ ...deliveryForm, carrier: value })}>
                  <SelectTrigger id="carrier">
                    <SelectValue placeholder="Select carrier" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fedex">FedEx</SelectItem>
                    <SelectItem value="ups">UPS</SelectItem>
                    <SelectItem value="dhl">DHL</SelectItem>
                    <SelectItem value="usps">USPS</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setNewDeliveryOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleNewDelivery}>
                  Create Delivery
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
}
