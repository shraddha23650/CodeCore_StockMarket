import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, TrendingDown, ArrowDownToLine, ArrowUpFromLine, ArrowLeftRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const stats = [
  { name: "Total Products", value: "1,284", icon: Package, color: "text-primary" },
  { name: "Low Stock Items", value: "23", icon: TrendingDown, color: "text-warning" },
  { name: "Pending Receipts", value: "8", icon: ArrowDownToLine, color: "text-info" },
  { name: "Pending Deliveries", value: "12", icon: ArrowUpFromLine, color: "text-secondary" },
  { name: "Active Transfers", value: "5", icon: ArrowLeftRight, color: "text-accent" },
];

const recentActivity = [
  { type: "Receipt", ref: "RCV-001", product: "iPhone 14 Pro", qty: "+50", date: "2 hours ago", status: "completed" },
  { type: "Delivery", ref: "DEL-023", product: "MacBook Air M2", qty: "-10", date: "3 hours ago", status: "completed" },
  { type: "Transfer", ref: "TRF-015", product: "AirPods Pro", qty: "25", date: "5 hours ago", status: "pending" },
  { type: "Adjustment", ref: "ADJ-008", product: "iPad Pro 11", qty: "+5", date: "6 hours ago", status: "completed" },
  { type: "Receipt", ref: "RCV-002", product: "Apple Watch Ultra", qty: "+30", date: "8 hours ago", status: "draft" },
];

const lowStockAlerts = [
  { product: "Magic Mouse", sku: "ACC-001", stock: 5, threshold: 20, warehouse: "Main WH" },
  { product: "USB-C Cable 2m", sku: "ACC-045", stock: 12, threshold: 50, warehouse: "Main WH" },
  { product: "MacBook Pro 16", sku: "LAP-003", stock: 3, threshold: 10, warehouse: "Store A" },
  { product: "HomePod Mini", sku: "AUD-012", stock: 8, threshold: 25, warehouse: "Store B" },
];

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground">Overview of your inventory operations</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {stats.map((stat) => (
          <Card key={stat.name}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.name}
              </CardTitle>
              <stat.icon className={`w-5 h-5 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Type</TableHead>
                  <TableHead>Reference</TableHead>
                  <TableHead>Product</TableHead>
                  <TableHead>Qty</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentActivity.map((activity) => (
                  <TableRow key={activity.ref}>
                    <TableCell className="font-medium">{activity.type}</TableCell>
                    <TableCell className="text-muted-foreground">{activity.ref}</TableCell>
                    <TableCell>{activity.product}</TableCell>
                    <TableCell className={activity.qty.startsWith('+') ? 'text-success' : activity.qty.startsWith('-') ? 'text-destructive' : 'text-foreground'}>
                      {activity.qty}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          activity.status === "completed"
                            ? "default"
                            : activity.status === "pending"
                            ? "secondary"
                            : "outline"
                        }
                      >
                        {activity.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Low Stock Alerts */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingDown className="w-5 h-5 text-warning" />
              Low Stock Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead>SKU</TableHead>
                  <TableHead>Stock</TableHead>
                  <TableHead>Warehouse</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {lowStockAlerts.map((alert) => (
                  <TableRow key={alert.sku}>
                    <TableCell className="font-medium">{alert.product}</TableCell>
                    <TableCell className="text-muted-foreground">{alert.sku}</TableCell>
                    <TableCell>
                      <span className="text-warning font-semibold">{alert.stock}</span>
                      <span className="text-muted-foreground text-sm"> / {alert.threshold}</span>
                    </TableCell>
                    <TableCell className="text-sm">{alert.warehouse}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
