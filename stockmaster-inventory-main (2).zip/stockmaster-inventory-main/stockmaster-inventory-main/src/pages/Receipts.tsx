import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function Receipts() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    supplier: "",
    poNumber: "",
    item: "",
    receivingLocation: "",
    quantity: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.supplier || !formData.item || !formData.receivingLocation || !formData.quantity) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Receipt Recorded",
      description: `Successfully recorded receipt for ${formData.quantity} units of ${formData.item}`,
    });

    // Reset form
    setFormData({
      supplier: "",
      poNumber: "",
      item: "",
      receivingLocation: "",
      quantity: "",
    });
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Receipt</h1>
          <p className="text-muted-foreground mt-2">Record incoming inventory and shipments</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Receive Items</CardTitle>
            <CardDescription>Record items received from suppliers</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="supplier">Supplier</Label>
                <Select value={formData.supplier} onValueChange={(value) => setFormData({ ...formData, supplier: value })}>
                  <SelectTrigger id="supplier">
                    <SelectValue placeholder="Select supplier" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="supplier1">Supplier 1</SelectItem>
                    <SelectItem value="supplier2">Supplier 2</SelectItem>
                    <SelectItem value="supplier3">Supplier 3</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="po-number">PO Number</Label>
                <Input 
                  id="po-number" 
                  placeholder="Enter purchase order number"
                  value={formData.poNumber}
                  onChange={(e) => setFormData({ ...formData, poNumber: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="item">Item</Label>
                <Select value={formData.item} onValueChange={(value) => setFormData({ ...formData, item: value })}>
                  <SelectTrigger id="item">
                    <SelectValue placeholder="Select item received" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="item1">Item 1</SelectItem>
                    <SelectItem value="item2">Item 2</SelectItem>
                    <SelectItem value="item3">Item 3</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="receiving-location">Receiving Location</Label>
                <Select value={formData.receivingLocation} onValueChange={(value) => setFormData({ ...formData, receivingLocation: value })}>
                  <SelectTrigger id="receiving-location">
                    <SelectValue placeholder="Select location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="warehouse-a">Warehouse A</SelectItem>
                    <SelectItem value="warehouse-b">Warehouse B</SelectItem>
                    <SelectItem value="warehouse-c">Warehouse C</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="quantity">Quantity</Label>
                <Input 
                  id="quantity" 
                  type="number" 
                  placeholder="Enter quantity received"
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                />
              </div>

              <Button type="submit" className="w-full">Record Receipt</Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
}
