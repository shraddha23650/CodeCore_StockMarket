import { NavLink } from "@/components/NavLink";
import {
  LayoutDashboard,
  Package,
  ArrowDownToLine,
  ArrowUpFromLine,
  ArrowLeftRight,
  ClipboardList,
  History,
  Warehouse,
  Settings,
} from "lucide-react";

const navigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Products", href: "/products", icon: Package },
  { name: "Receipts", href: "/receipts", icon: ArrowDownToLine },
  { name: "Deliveries", href: "/deliveries", icon: ArrowUpFromLine },
  { name: "Transfers", href: "/transfers", icon: ArrowLeftRight },
  { name: "Adjustments", href: "/adjustments", icon: ClipboardList },
  { name: "Move History", href: "/history", icon: History },
  { name: "Warehouses", href: "/warehouses", icon: Warehouse },
  { name: "Settings", href: "/settings", icon: Settings },
];

export function Sidebar() {
  return (
    <aside className="fixed left-0 top-0 h-screen w-64 bg-card border-r border-border flex flex-col">
      <div className="p-6 border-b border-border">
        <h1 className="text-2xl font-bold text-primary flex items-center gap-2">
          <Package className="w-7 h-7" />
          StockMaster
        </h1>
      </div>
      
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {navigation.map((item) => (
          <NavLink
            key={item.name}
            to={item.href}
            end={item.href === "/"}
            className="flex items-center gap-3 px-4 py-3 rounded-lg text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
            activeClassName="bg-primary/10 text-primary font-medium hover:bg-primary/15"
          >
            <item.icon className="w-5 h-5" />
            <span>{item.name}</span>
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
